#!/bin/bash

rm `find . -name "*.out*"`
rm `find . -name "*.moon"`

